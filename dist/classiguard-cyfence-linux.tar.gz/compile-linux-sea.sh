#!/bin/sh
# Compile into a native single ELF binary on any Linux host with Node >= 20:
echo "Compiling ClassiGuard CyFence native Linux ELF binary..."
node --experimental-sea-config sea-config.json
cp $(which node) cyfence-bin
npx postject cyfence-bin NODE_SEA_BLOB sea-prep.blob --sentinel-fuse NODE_SEA_FUSE_fce680ab2cc467b6e072b8b5df1996b2 --overwrite
chmod +x cyfence-bin
echo "Done! Run ./cyfence-bin --help"
